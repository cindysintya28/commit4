@extends('layouts.app')

@section('title','cobaaaaaaa')

@section('content')
    urutan ke - {{ $ke }}
@endsection